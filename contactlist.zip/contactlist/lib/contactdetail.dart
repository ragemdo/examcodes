import 'package:flutter/material.dart';

class contactdetail extends StatelessWidget {
  const contactdetail({super.key});

   @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const ProfilePage(),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 255, 255, 255),
      body: SingleChildScrollView(
        child: Center(
        ),
      ),
    );
  }
}

Widget Profile() {
  return Padding(
    padding: const EdgeInsets.all(10),
    child: Column(
      children: [
         CircleAvatar(
          radius: 20.0,
          backgroundImage: AssetImage('assets/blankprofile.jpg'),
        ),
                const SizedBox(width: 20),
                Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                Text(
                "",
                style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                fontFamily: 'Arial',
                color: const Color.fromARGB(255, 0, 0, 0),
              ),
            ),
          ],
        ),
      ]
    ),
  );
}
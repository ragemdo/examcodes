import 'package:flutter/material.dart';

class Addcontact extends StatefulWidget {
  @override
  _AddContactDataPageState createState() => _AddContactDataPageState();
}

class _AddContactDataPageState extends State<Addcontact> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _birthdateController = TextEditingController();
  final TextEditingController _jobController = TextEditingController();




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            const Text("First name"),
            buildTextField("Enter your First Name", _nameController),
            const Text("Last name"),
            buildTextField("Enter your Last Name", _birthdateController),
            const Text("Phone number"),
            buildTextField("63+ 9__ ___ ____", _jobController),

            const SizedBox(height: 20)
          ],
        ),
      ),
    );
  }

  Widget buildTextField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(),
        ),
      ),
    );
  }
}

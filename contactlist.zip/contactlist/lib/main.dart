import 'package:contactlist/addcontact.dart';
import 'package:contactlist/contactdetail.dart';
import 'package:flutter/material.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const ProfilePage(),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 255, 255, 255),
      body: SingleChildScrollView(
        child: Column(
          children: [
            contacts(), 
            contactlist(context),
            button(context),
          ],
        ),
      ),
    );
  }
}

// Profile Header
Widget contacts() {
  return Padding(
    padding: const EdgeInsets.all(10),
    child: Row(
      children: [
                const SizedBox(width: 20),
                Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                Text(
                "Contacts",
                style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                fontFamily: 'Arial',
                color: const Color.fromARGB(255, 0, 0, 0),
              ),
            ),
          ],
        ),
      ]
    ),
  );
}


// Menu List
Widget contactlist(BuildContext context) {
  return Column(
    children: [
      contact(Icons.person, "Chrissandra Bautista", () {
        Navigator.push(context,
        MaterialPageRoute(builder: (context) => const contactdetail())
        );
      }),
            const SizedBox(height: 5),
      contact(Icons.person, "Josh Nimo", () {}),
            const SizedBox(height: 5),
      contact(Icons.person, "Shelou Asaris", () {}),
                  const SizedBox(height: 5),
      contact(Icons.person, "Ace Advincula", () {}),
                  const SizedBox(height: 5),
      contact(Icons.person, "Crislyn Delgado", () {}),
                  const SizedBox(height: 5),
      contact(Icons.person, "Airene Tungol", () {}),
            const SizedBox(height: 5),
      contact(Icons.person, "James  Legado", () {}),
            const SizedBox(height: 5),
      contact(Icons.person, "Kharl Almonguerra", () {}),
                  const SizedBox(height: 5),
      contact(Icons.person, "VinceCarabuena", () {}),
                  const SizedBox(height: 5),
      contact(Icons.person, "Errol De Pedro", () {}),
                        const SizedBox(height: 15)
    ],
  );
}

Widget contact(IconData icon, String title, VoidCallback onTap) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
      child: Container(
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 186, 185, 185),
        borderRadius: BorderRadius.circular(10),
      ),
      child: ListTile(
        leading: Icon(icon, color: const Color.fromARGB(255, 0, 0, 0)),
        title: Text(title, style: const TextStyle(fontSize: 16, color: Color.fromARGB(255, 0, 0, 0))),
        trailing: const Icon(Icons.phone, color: Color.fromARGB(255, 105, 191, 0)),
        onTap: onTap,
      ),
    ),
  );
}

Widget button(BuildContext context) {
  return Column(
    children: [
      contact(Icons.add, "", () {
        Navigator.push(context,
        MaterialPageRoute(builder: (context) => Addcontact())
        );
      }),
    ],
  );
}

Widget addone(IconData icon, String title, VoidCallback onTap) {
  return Padding(
    padding: const EdgeInsets.all(30),
      child: Container(
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 27, 38, 200),
        borderRadius: BorderRadius.circular(10),
        
      ),
    ),
  );
}

